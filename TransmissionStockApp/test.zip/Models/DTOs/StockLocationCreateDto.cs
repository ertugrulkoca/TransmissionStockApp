﻿namespace TransmissionStockApp.Models.DTOs
{
    public class StockLocationCreateDto
    {
        public string ShelfCode { get; set; } = null!;
    }
}
