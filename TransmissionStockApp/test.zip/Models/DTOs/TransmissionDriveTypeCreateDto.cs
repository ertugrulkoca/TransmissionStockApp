﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionDriveTypeCreateDto
    {
        public string Name { get; set; } = null!;
    }
}
