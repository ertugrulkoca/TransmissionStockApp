﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionStockLocationUpdateDto
    {
        public int TransmissionStockId { get; set; }
        public int StockLocationId { get; set; }
        public int Quantity { get; set; }
    }

}
