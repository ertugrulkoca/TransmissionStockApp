﻿namespace TransmissionStockApp.Models.DTOs
{
    public class StockLocationQuantityDto
    {
        public string ShelfCode { get; set; } = null!;
        public int Quantity { get; set; }
    }
}
