﻿namespace TransmissionStockApp.Models.DTOs
{
    public class StockLocationUpdateDto
    {
        public int Id { get; set; }
        public string ShelfCode { get; set; } = null!;
    }
}
