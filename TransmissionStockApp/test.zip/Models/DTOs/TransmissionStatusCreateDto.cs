﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionStatusCreateDto
    {
        public string Name { get; set; } = null!;
    }
}
