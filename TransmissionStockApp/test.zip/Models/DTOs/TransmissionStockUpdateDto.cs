﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionStockUpdateDto : TransmissionStockCreateDto
    {
        public int Id { get; set; }
    }
}
