﻿namespace TransmissionStockApp.Models.DTOs
{
    public class VehicleBrandCreateDto
    {
        public string Name { get; set; } = null!;
    }
}
