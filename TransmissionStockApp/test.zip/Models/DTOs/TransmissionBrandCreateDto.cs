﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionBrandCreateDto
    {
        public string Name { get; set; } = null!;
    }
}
