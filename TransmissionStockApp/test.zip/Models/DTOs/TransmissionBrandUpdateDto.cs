﻿namespace TransmissionStockApp.Models.DTOs
{
    public class TransmissionBrandUpdateDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
