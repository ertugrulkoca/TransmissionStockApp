﻿namespace TransmissionStockApp.Models.ViewModels
{
    public class TransmissionStatusViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
