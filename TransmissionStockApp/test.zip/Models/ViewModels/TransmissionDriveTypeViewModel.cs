﻿namespace TransmissionStockApp.Models.ViewModels
{
    public class TransmissionDriveTypeViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
