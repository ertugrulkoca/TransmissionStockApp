﻿namespace TransmissionStockApp.Models.ViewModels
{
    public class VehicleBrandViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
